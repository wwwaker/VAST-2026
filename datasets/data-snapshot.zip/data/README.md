# VAST 2026 课程数据交接

解压后从本文件开始。需要复查来源时看 `raw/`，需要读取标准事件、统计结果或接入图表时看 `process/`。三套数据独立使用各自的时间轴。

| 目录或文件 | 内容 |
| --- | --- |
| `raw/official_data/MC1/`、`raw/official_data/MC2/` | 官方原始 ZIP。MC1 包含按轮次组织的通信日志，MC2 包含系统操作日志和组织图。 |
| `raw/custom_dataset/<run_id>/events.jsonl` | 32 次自建运行的原始事件日志，每次运行一个文件。 |
| [process/official_data/MC1/](process/official_data/MC1/README.md) | 标准化通信事件和实体。912 条消息、7 个 Agent、23 轮。 |
| [process/official_data/MC2/](process/official_data/MC2/README.md) | 标准化系统事件、实体和组织关系。185,147 条事件，24 类操作。 |
| [process/custom_dataset/](process/custom_dataset/README.md) | 1,103 条协作事件、实体与版本、32 条运行级标签。共 180 次模型调用。 |
| [process/analysis/analysis.json](process/analysis/analysis.json) | 三套数据的统计结果，包括 MC1 加权通信网络、MC2 相邻事件分析、自建流程配对统计。 |
| [process/views/manifest.json](process/views/manifest.json) | 可视化数据入口、源事件路径、记录规模及 SHA-256。清单中的路径相对于本 README 所在目录。 |

## 如何读取

- `events.jsonl` 使用 UTF-8，每行是一个 JSON 对象。用 `event_id` 定位事件，用 `actor_id` 关联 `entities.json` 中的 `entity_id`，用 `parent_event_id` 查明确的前序事件。MC1、MC2 的实体位于 `entities` 数组，自建实体文件本身就是数组。
- MC1、MC2 可用 `source_file` 和 `source_json_pointer` 回查官方 ZIP 中的原始 JSON。MC1 保留原始模拟时间，时区未知。MC2 和自建数据使用 UTC。
- MC1 收件关系读 `relationships`，一条消息可以关联多名收件人。广播保留为消息。MC2 的 `party_ids` 表示参与方，`actor_id` 表示有依据的执行者。322 条执行者未知的操作保留在完整事件表中。
- 自建数据用 `run_id` 连接 `events.jsonl` 和 `labels.json`，用 `affected_event_ids` 找相关事件。`scenario` 是运行条件，`observed` 表示实际是否观察到对应异常。

## 额外统计与图表数据

| 数据 | 可直接读取的文件 | 内容和用法 |
| --- | --- | --- |
| MC1 | [views.json](process/views/mc1/views.json) | `heatmaps` 做日和小时活动图，`timeline` 和 `market_by_bucket` 做轮次与市场走势，`network` 区分回复、称呼与明确收件关系。用 `messages_by_id` 和 `reply_threads_by_root` 下钻。 `additional_stats` 包含阶段、渠道、对话线程、主题词和解禁前后统计。 |
| MC2 | [views.json](process/views/mc2/views.json)、[transition_pairs.jsonl](process/views/mc2/transition_pairs.jsonl)、[file_tracks.jsonl](process/views/mc2/file_tracks.jsonl) | `activity` 做活动热图，`network_edges` 和 `organization_edges` 做关系图，`transitions` 做操作转移矩阵。另有 30 分钟窗口的 171,768 对事件明细及 15,310 个文件的操作轨迹。相邻对按 `lag_seconds <= 300` 可取出 5 分钟子集。 |
| 自建数据 | [views.json](process/views/custom/views.json) | `runs` 和 `workflow_edges` 做单次流程时间线，`handoff_role_network` 做交接网络，`condition_aggregates` 与 `matched_comparisons` 做按条件、模型和任务的对照。可下钻到审核、读取版本与发布结果。 |

MC2 和自建视图目录中的 `event_locator.json` 将事件 ID 映射为 `[字节偏移, 字节长度]`。对清单中对应的 `source_events` 文件按二进制读取。请保留原文件编码与换行，修改后需重建偏移索引。

- **MC1 通信网络统计**按明确收件关系计权，排除广播和自连。225 条消息贡献 410 次计权连接，加权互惠率为 48.3%。可视化文件还提供按回复和称呼构建的网络层，各层采用不同关系定义。文本情绪分数来自简易词表，危机事件标记包含人工研判。
- **MC2 相邻事件统计**按同一执行者排序，跳过执行者未知的记录，排除至少一端时间并列的候选对。30 分钟窗口中「门禁检查后进入房间」出现 2,488 次，执行者校正提升度为 13.78 倍。该结果用于观察操作顺序关联。
- **自建流程统计**按同一模型和任务对照正常与异常条件，每类异常有 8 对。旧版条件下，8 次读到旧版，其中 5 次实际发布旧版、3 次发布被拒绝。配对结果用于解释本批实验流程的差异。
