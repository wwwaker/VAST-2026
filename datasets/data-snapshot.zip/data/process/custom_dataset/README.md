# 自建 Multi-Agent 数据

- [entities.json](entities.json) 是实体数组。角色、任务、文档、文件和版本通过 `entity_id` 标识。
- [events.jsonl](events.jsonl) 包含 32 次真实运行。使用 `run_id` 筛选运行。时间为 UTC。
- [labels.json](labels.json) 是运行级结果数组。使用 `run_id` 关联运行，使用 `affected_event_ids` 定位事件。`scenario` 是流程条件，`anomaly_type` 是异常类别，`observed` 表示是否观察到异常，`reason` 是结果简述。

事件文件为 UTF-8 JSONL，每行一个 JSON 对象，可逐行读取。

| 字段 | 类型与用途 |
| --- | --- |
| `event_id` | 字符串，事件主键 |
| `run_id` | 字符串或 null，按运行筛选 |
| `timestamp` | ISO 8601 字符串 |
| `actor_id`、`target_id` | 字符串或 null，通过 `entity_id` 关联实体 |
| `event_type` | 字符串，按类型筛选 |
| `task_id`、`document_id` | 字符串或 null，关联任务和文档 |
| `version` | 整数或 null |
| `parent_event_id` | 字符串或 null，关联同一数据集的 `event_id` |
| `details` | JSON 对象或 null，业务字段因事件类型而异 |

[数据包使用说明和统计结果](../../README.md)。
