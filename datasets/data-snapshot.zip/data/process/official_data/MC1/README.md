# 官方 MC1 · 危机沟通消息

- [entities.json](entities.json) 是对象，实体位于 `entities` 数组。
- [events.jsonl](events.jsonl) 是事件表。 MC1 用源时间，时区未知。可按 `channel_id` 分组，`relationships` 提供明确收件关系。
- `source_record_id` 是官方记录 ID，`raw` 保留源载荷。

事件文件为 UTF-8 JSONL，每行一个 JSON 对象，可逐行读取。

| 字段 | 类型与用途 |
| --- | --- |
| `event_id` | 字符串，事件主键 |
| `run_id` | 字符串或 null，按运行筛选 |
| `timestamp` | ISO 8601 字符串 |
| `actor_id`、`target_id` | 字符串或 null，通过 `entity_id` 关联实体 |
| `event_type` | 字符串，按类型筛选 |
| `task_id`、`document_id` | 字符串或 null，关联任务和文档 |
| `version` | 整数或 null |
| `parent_event_id` | 字符串或 null，关联同一数据集的 `event_id` |
| `details` | JSON 对象或 null，业务字段因事件类型而异 |

[数据包使用说明和统计结果](../../../README.md)。
