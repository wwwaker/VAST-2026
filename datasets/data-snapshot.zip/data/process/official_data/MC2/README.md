# 官方 MC2 · 内部系统活动

- [entities.json](entities.json) 是对象，实体位于 `entities` 数组。 组织关系位于 `org_edges`，每条边的 `source` 和 `target` 关联实体。
- [events.jsonl](events.jsonl) 是事件表。 MC2 使用 UTC。可按 `event_type`、`actor_id` 或日期筛选。`party_ids` 是参与方列表，`relationships` 是有类型的关系。
- `source_record_id` 是官方记录 ID，`raw` 保留源载荷。

事件文件为 UTF-8 JSONL，每行一个 JSON 对象，可逐行读取。

| 字段 | 类型与用途 |
| --- | --- |
| `event_id` | 字符串，事件主键 |
| `run_id` | 字符串或 null，按运行筛选 |
| `timestamp` | ISO 8601 字符串 |
| `actor_id`、`target_id` | 字符串或 null，通过 `entity_id` 关联实体 |
| `event_type` | 字符串，按类型筛选 |
| `task_id`、`document_id` | 字符串或 null，关联任务和文档 |
| `version` | 整数或 null |
| `parent_event_id` | 字符串或 null，关联同一数据集的 `event_id` |
| `details` | JSON 对象或 null，业务字段因事件类型而异 |

[数据包使用说明和统计结果](../../../README.md)。
